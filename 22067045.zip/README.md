# Enhanced GUI for Classical Machine Learning Methods  

This project enhances the provided GUI application by adding new features, improving usability, and ensuring correct classification/regression functionality.  

## Major Changes & Enhancements 

### 1. Logistic Regression Tab Correction
- In the base code, *Logistic Regression* was in the Regression tab. However, despite its name, it is actually a classification method.  
- It has been moved to the Classification tab in the GUI.  
- Its implementation was moved to the `train_model` function alongside other classification and regression methods.  

### 2. Adding Support Vector Machine (SVM) 
- SVM (Support Vector Machine) has been added to both classification and regression sections.  
- It replaces Logistic Regression’s previous spot in the Regression tab.  
- Kernel selection is now available (Linear, RBF, Polynomial).  
- Hyperparameters like C (regularization) and epsilon (for SVR) are implemented.  

### 3. Naïve Bayes Section (GaussianNB)
- The existing Naïve Bayes section remains unchanged in the GUI as its `var_smoothing` parameter was already provided.  
- Implemented its logic in `train_model` using the given variable.  
- Added class probability visualization under the Classification tab.  

### 4. Selectable Loss Functions for Models 
- Implemented loss function selection for both classification and regression:  
  - **Regression:**
    - Mean Squared Error (MSE)  
    - Mean Absolute Error (MAE)  
    - Huber Loss  
  - **Classification:**  
    - Cross-Entropy  
    - Hinge Loss  
- Model training logic dynamically selects the loss function.  

### 5. Performance Comparison of Loss Functions  
- Regression models were tested using MSE, MAE, and Huber Loss.  
  - *Huber Loss performed the best, producing the lowest error.  
- Classification models were tested using Cross-Entropy and Hinge Loss on the Breast Cancer dataset.  
  - Cross-Entropy performed better than Hinge Loss.  

## How To Use The Code?  

### 1. Select the Dataset & Model Type Correctly  
- Ensure that the selected dataset matches the intended model type.  
- Classification datasets should not be used for regression models, and vice versa.  

### 2. Adjust Parameters as Needed  
After loading the dataset, users can modify various parameters, such as:  

- Loss Function (Available for both Classification and Regression)  
- C and Iteration Values (For Classification)  
- C, Kernel Type, and Degree Values (For SVM)  

### 3. Train the Model & View Results  
- Once the dataset is selected and parameters are adjusted, press the "Train ..." button in the corresponding section.  
- The results will be displayed as:  
  - A visualization tab showing real vs. predicted data (For Regression)  
  - Another visualization tab displaying classified data (For Classification)  

### 4. Analyze the Model’s Performance  
A dedicated Loss & R² Score segment shows the difference between real data and the model’s predictions.  